//
// Created by mariakolyachko on 3.02.20.
//

#ifndef COURSE_PROJECT_SEARCH_SERVER_H
#define COURSE_PROJECT_SEARCH_SERVER_H

#include <deque>
#include <istream>
#include <list>
#include <map>
#include <ostream>
#include <set>
#include <string>
#include <vector>
using namespace std;

class InvertedIndex {
public:
  void Add(const string &document);
  [[nodiscard]] const vector<pair<size_t, size_t>> &
  Lookup(const string &word) const;

  [[nodiscard]] const string &GetDocument(size_t id) const { return docs[id]; }

  [[nodiscard]] size_t GetDocumentCount() const { return docs.size(); }

private:
  vector<vector<pair<size_t, size_t>>> index;
  map<string, size_t> ids;
  vector<string> docs;

  vector<pair<size_t, size_t>> empty;
};

using SearchResult = vector<pair<size_t, size_t>>;

class SearchServer {
public:
  SearchServer() = default;
  explicit SearchServer(istream &document_input);
  void UpdateDocumentBase(istream &document_input);
  void AddQueriesStream(istream &query_input, ostream &search_results_output);

private:
  InvertedIndex index;
};

#endif // COURSE_PROJECT_SEARCH_SERVER_H
